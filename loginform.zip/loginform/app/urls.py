from django.contrib import admin
from django.urls import path
from app.views import signuppage,loginpage,homepage,Logout

urlpatterns = [
    path('admin/', admin.site.urls),
    path('',signuppage,name='signup'),
    path('login/',loginpage,name='login'),
    path('next/',homepage,name='home'),
    path('logout/',Logout,name='logout'),
]